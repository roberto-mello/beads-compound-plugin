import type { Plugin } from "@opencode-ai/plugin"

export const ConvertedHooks: Plugin = async ({ $ }) => {
  return {
    "session.created": async (input) => {
    await $`${CLAUDE_PLUGIN_ROOT}/hooks/auto-recall.sh`
    },
    "tool.execute.after": async (input) => {
    if (input.tool === "bash") { await $`${CLAUDE_PLUGIN_ROOT}/hooks/memory-capture.sh` }
    },
    "message.updated": async (input) => {
    // Claude SubagentStop
    await $`${CLAUDE_PLUGIN_ROOT}/hooks/subagent-wrapup.sh`
    }
  }
}

export default ConvertedHooks

